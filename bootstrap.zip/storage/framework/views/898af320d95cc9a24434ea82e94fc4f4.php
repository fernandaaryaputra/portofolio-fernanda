
<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('user')): ?>
    <script>
        Swal.fire({
            title: "Warning",
            text: "<?php echo e(Session::get('user')); ?>",
            // background: "#00C853"
            // color: "#FAFAFA",
            icon: "error"
        });
    </script>
<?php endif; ?>
<?php if($message = Session::get('registerberhasil')): ?>
    <script>
        Swal.fire({
            title: "DONE",
            text: "<?php echo e(Session::get('registerberhasil')); ?>",
            // background: "#00C853"
            // color: "#FAFAFA",
            icon: "success"
        });
    </script>
<?php endif; ?>
<?php if($message = Session::get('signout')): ?>
    <script>
        Swal.fire({
            title: "<?php echo e(session::get('signout')); ?>",
            // background: "#00C853"
            // color: "#FAFAFA",
            icon: "error"
        });
    </script>
<?php endif; ?>
<div id="layoutAuthentication">
    <div id="layoutAuthentication_content">
        <main>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5">
                        <div class="card shadow-lg border-0 rounded-lg mt-5">
                            
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <div class="card-header">
                                <div class="text-center  ">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"  width ="80" height="80" class="mx-auto"><path d="M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13Z" ></path></svg>
                                    
                                </div>
                               
                                <h3 class="text-center  my-4 text-4xl font-bold text-black">Login</h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(url('proses_login')); ?>" method="POST" id="logForm">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <?php $__errorArgs = ['login_gagal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            
                                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                                
                                                <span class="alert-inner--text"><strong>Warning!</strong>  <?php echo e($message); ?></span>
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <label class="small mb-1" for="inputEmailAddress">Username</label>
                                        <input
                                            class="form-control py-4"
                                            id="inputEmailAddress"
                                            name="username"
                                            type="text"
                                            placeholder="Masukkan Username"/>
                                        <?php if($errors->has('username')): ?>
                                        <span class="error"><?php echo e($errors->first('username')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="small mb-1" for="inputPassword">Password</label>
                                        <input
                                            class="form-control py-4"
                                            id="inputPassword"
                                            type="password"
                                            name="password"
                                            placeholder="Masukkan Password"/>
                                        <?php if($errors->has('password')): ?>
                                        <span class="error"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" id="rememberPasswordCheck" type="checkbox"/>
                                            <label class="custom-control-label" for="rememberPasswordCheck">Remember password</label>
                                        </div>
                                    </div>
                                    <div
                                        class="form-group d-flex align-items-center justify-content-between mt-4 mb-3">
                                        
                                            
                                            <button class="btn w-100  btn-block btn-login bg-blue-900 text-white hover:bg-black hover:text-white font-bold" type="submit">Login</button>
                                       
                                    </div>
                                    <hr>
                                    <a href="<?php echo e(url('/')); ?>" class="mt-5 text-red-600 hover:text-yellow-500 font-bold">< Kembali</a>
                                </form>
                            </div>
                            <div class="card-footer text-center">
                                <div class="small">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.aunth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webbarufernanda\resources\views/back/login.blade.php ENDPATH**/ ?>