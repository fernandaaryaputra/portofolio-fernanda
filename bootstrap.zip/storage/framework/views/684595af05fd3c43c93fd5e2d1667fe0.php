
<?php $__env->startSection('content'); ?>
<div id="layoutAuthentication">
    <div id="layoutAuthentication_content">
        <main>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="card shadow-lg border-0 rounded-lg mt-5">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="50" height="50" class="text-center mx-auto mt-5 fill-green-700"><path d="M12.8995 6.85453L17.1421 11.0972L7.24264 20.9967H3V16.754L12.8995 6.85453ZM14.3137 5.44032L16.435 3.319C16.8256 2.92848 17.4587 2.92848 17.8492 3.319L20.6777 6.14743C21.0682 6.53795 21.0682 7.17112 20.6777 7.56164L18.5563 9.68296L14.3137 5.44032Z"></path></svg>
                            <div class="card-header"><h3 class="text-center font-weight-light my-4 font-bold text-2xl">Create Account</h3></div>
                            <div class="card-body">
                                <form action="<?php echo e(route('proses_register')); ?>" method="POST" id="regForm">
                                <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label class="small mb-1" for="inputFirstName">Nama</label>
                                        <input class="form-control py-4" id="inputFirstName" type="text" name="name" placeholder="Masukkan Nama" />
                                         <?php if($errors->has('name')): ?>
                                          <span class="error"> * <?php echo e($errors->first('name')); ?></span>
                                          <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="small mb-1" for="inputusername">Username</label>
                                        <input class="form-control py-4" id="inputusername" type="text" name="username" placeholder="Masukkan username" />
                                         <?php if($errors->has('username')): ?>
                                          <span class="error"> * <?php echo e($errors->first('username')); ?></span>
                                          <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="small mb-1" for="inputEmailAddress">Email</label>
                                        <input class="form-control py-4" id="inputEmailAddress" type="email" aria-describedby="emailHelp" name="email" placeholder="Masukkan Email" />
                                        <?php if($errors->has('email')): ?>
                                          <span class="error">* <?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="small mb-1" for="inputPassword">Password</label>
                                        <input class="form-control py-4" id="inputPassword" type="password" name="password" placeholder="Masukkan Password" />
                                        <?php if($errors->has('password')): ?>
                                          <span class="error">* <?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mt-4 mb-0">
                                        <button class="btn btn-primary btn-block text-black" type="submit">Create</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-footer text-center">
                                <div class="small hover:text-blue-700"><a href="<?php echo e(route('login')); ?>">Sudah Punya Akun? Login!</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.aunth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\webbarufernanda\resources\views/back/register.blade.php ENDPATH**/ ?>